# PCF Measures

## Product: [value:product.name]

[value:product.description]

### Metadata

Here is some metadata from the __Product__:

[if:systemBoundary!=null]- System Boundary: [value:systemBoundary][if-end]
[if:unit.functionalUseCase!=null]- Functional Use Case: [value:unit.functionalUseCase][if-end]
[if:unit.referenceFlow!=null]- Reference Flow: [value:unit.referenceFlow][if-end]
[if:unit.amount>0]- Amount: [value:unit.amount][if-end]
[if:unit.amount>0]- Unit: [value:unit.unit][if-end]
[if:unit.type!=null&unit.type!=""]- Type: [value:unit.type][if-end]

### Project

Here is some information about the __Project__ in which your __Measures__ are recommended.

- Title: [value:title]
- Reference Period: From [value:referencePeriod.from date="%d.%m.%y"] to [value:referencePeriod.to date="%d.%m.%y"]

### Company

Here is some information about the __Company__ [value:product.company.name] that produces the __Product__:

[if:product.company.description!=""]- [value:product.company.description][if-end]
- The __Company__ has these __NACE__ codes: [loop:product.company.naceCodes as=naceCode join=", "][value:naceCode][loop-end].

### Locations

The __Product__ is produced in these __Locations__: 

[loop:locations as=location start=1]
[loop-index]. [value:location.company.name] [if:location.company.naceCodes] ([value:location.company.naceCodes])[if-end]
[loop-end]

### Emissions

The CO2e __Emissions__ of the __Product__ are:

[if:totalCo2e.value>0]- Total emissions: [value:totalCo2e.value] [value:totalCo2e.unit][if-end] 
[loop:locations as=location]
- Emissions in [value:location.company.name] (by Stage): 
  [loop:location.stages as=stage]
  - [value:stage.name]: [if:stage.totalCo2e.value>0][value:stage.totalCo2e.value] [value:stage.totalCo2e.unit][if-else]`None`[if-end]
  [loop-end]
[loop-end]

## Activities

The __Activities__ are organized in __Sub-Stages__ of __Stages__ that are __Location__-based as well as in __Stages__ that are __Location__-independent.

[loop:locations as=location]
### [value:location.company.name]
//
[loop:location.stages as=stage]
#### [value:stage.name]

[condense]
  [if:text[English.Name=[value:stage.name]|German.Name=[value:stage.name]].English.Description!=null]
    [value:text[English.Name=[value:stage.name]|German.Name=[value:stage.name]].English.Description]
  [if-else]
    This __Stage__ has no description.
  [if-end]
[condense-end]

The __Stage__ "[value:stage.name]" emits [if:stage.totalCo2e.value>0]a total of [value:stage.totalCo2e.value] [value:stage.totalCo2e.unit][if-else]no[if-end] CO2e __Emissions__.
//
[loop:stage.subStages as=substage]
##### [value:substage.name]

[condense]
  [if:text[English.Name=[value:substage.name]|German.Name=[value:substage.name]].English.Description!=null]
    [value:text[English.Name=[value:substage.name]|German.Name=[value:substage.name]].English.Description]
  [if-else]
    This __Sub-Stage__ has no description.
  [if-end]
[condense-end]

The __Sub-Stage__ "[value:substage.name]" emits [if:substage.totalCo2e.value>0]a total of [value:substage.totalCo2e.value] [value:substage.totalCo2e.unit][if-else]no[if-end] CO2e __Emissions__.

[loop:substage.activities as=activity]
[condense]
- **Activity "[value:activity.name]"**: 
    [if:activity.totalCo2e.value>0]
      __Total Emissions__ amount to [value:activity.totalCo2e.value] [value:activity.totalCo2e.unit]
    [if-else]
      There are no total
    [if-end] 
    CO2e emissions
    [if:activity.value.value>0]
      , derived from [value:activity.value.value] [value:activity.value.unit] of __Input__
      [if:activity.factor.factor>0]
        and an __Emission Factor__ of [value:activity.factor.factor] [value:activity.factor.unit]
        [if:activity.factor.source!=null|activity.factor.type!=null|activity.factor.year!=null]([if-end]
          [if:activity.factor.type!=null]type: [value:activity.factor.type],[if-end]
          [if:activity.factor.source!=null&activity.factor.source!=""]source: [value:activity.factor.source],[if-end]
          [if:activity.factor.year!=null]year: [value:activity.factor.year][if-end]
        [if:activity.factor.source!=null|activity.factor.type!=null|activity.factor.year!=null])[if-end]
      [if-end]
    [if-end]
    .
    [if:activity.uncertainty!=null]
      __Uncertainty__: "[value:activity.uncertainty]".
    [if-end]
    [if:activity.comment!=null]
      __Comment__: "[value:activity.comment]".
    [if-end]
[condense-end]
[loop-end]

[loop-end]
[loop-end]
[loop-end]

### Location-independent

Location-independent Activities are not grouped in Sub-Stages.
// 
[loop:stages as=stage]
#### [value:stage.name]

[condense]
  [if:text[English.Name=[value:stage.name]|German.Name=[value:stage.name]].English.Description!=null]
    [value:text[English.Name=[value:stage.name]|German.Name=[value:stage.name]].English.Description]
  [if-else]
    This __Stage__ has no description.
  [if-end]
[condense-end]

The Stage "[value:stage.name]" emits [if:stage.totalCo2e.value>0]a total of [value:stage.totalCo2e.value] [value:stage.totalCo2e.unit][if-else]no[if-end] CO2e emissions.

[loop:stage.activities as=activity]
[condense]
- **Activity "[value:activity.name]"**: 
    [if:activity.totalCo2e.value>0]
      __Total Emissions__ amount to [value:activity.totalCo2e.value] [value:activity.totalCo2e.unit]
    [if-else]
      There are no total
    [if-end] 
    CO2e emissions
    [if:activity.value.value>0]
      , derived from [value:activity.value.value] [value:activity.value.unit] of __Input__
      [if:activity.factor.factor>0]
        and an __Emission Factor__ of [value:activity.factor.factor] [value:activity.factor.unit]
        [if:activity.factor.source!=null|activity.factor.type!=null|activity.factor.year!=null]([if-end]
          [if:activity.factor.type!=null]type: [value:activity.factor.type],[if-end]
          [if:activity.factor.source!=null&activity.factor.source!=""]source: [value:activity.factor.source],[if-end]
          [if:activity.factor.year!=null]year: [value:activity.factor.year][if-end]
        [if:activity.factor.source!=null|activity.factor.type!=null|activity.factor.year!=null])[if-end]
      [if-end]
    [if-end]
    .
    [if:activity.uncertainty!=null]
      __Uncertainty__: "[value:activity.uncertainty]".
    [if-end]
    [if:activity.comment!=null]
      __Comment__: "[value:activity.comment]".
    [if-end]
[condense-end]
[loop-end]

[loop-end]

### Commented

Users can add a __Comment__ to any __Activity__. 
It is likely that a comment indicates open tasks or questions, so take them into account.
This is a list of all __Activities__ that are commented:

[loop:locations as=location]
  [loop:location.stages as=stage]
    [loop:stage.subStages as=substage]
      [loop:substage.activities as=activity start=1]
        [if:activity.comment!=null & activity.comment!=""]
          [set:foundComment=true]
- [condense]
    [value:location.company.name] > 
    [value:stage.name] > 
    [value:substage.name] > 
    [value:activity.name]: 
    [value:activity.comment]
  [condense-end]
        [if-end]
      [loop-end]
    [loop-end]
  [loop-end]
[loop-end]
[loop:stages as=stage]
  [loop:stage.activities as=activity start=1]
    [if:activity.comment!=null & activity.comment!=""]
      [set:foundComment=true]
- [condense]
  [value:stage.name] > 
  [value:activity.name]: 
  [value:activity.comment]
[condense-end]
    [if-end]
  [loop-end]
[loop-end]
[if:foundComment!=true]
- There are no commented __Activities__.
[if-end]

## Missing Fields

Location-based measures with missing emissions:

[loop:locations as=location]
  [loop:location.stages as=stage]
    [loop:stage.subStages as=substage]
      [loop:substage.activities as=activity]
        [if:activity.totalCo2e.value=0]
          [set:hasPredefinedMeasures=true]
[condense]
- [value:activity.name]
  (
    in Location [value:location.company.name], 
    Stage [value:stage.name], 
    Sub-Stage [value:substage.name]
  )
  is missing a consumption value.
[condense-end]
        [if-end]
      [loop-end]
    [loop-end]
  [loop-end]
[loop-end]

Location-independent measures with missing emissions:

[loop:stages as=stage]
  [loop:stage.activities as=activity]
    [if:activity.totalCo2e.value=0]
      [set:hasPredefinedMeasures=true]
[condense]
- [value:activity.name]
  (
    in Stage [value:stage.name]
  ) 
  a consumption value is missing.
[condense-end]
    [if-end]
  [loop-end]
[loop-end]
[if:hasPredefinedMeasures!=true]
- There are no predefined measures.
[if-end]
