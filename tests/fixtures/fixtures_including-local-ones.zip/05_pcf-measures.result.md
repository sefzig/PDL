# PCF Measures

## Product: Slider Rave

This is the product description.

### Metadata

Here is some metadata from the __Product__:

- Amount: 1000
- Unit: number
- Type: DeclaredUnit

### Project

Here is some information about the __Project__ in which your __Measures__ are recommended.

- Title: Slider Rave
- Reference Period: From 01.01.23 to 31.12.25

### Company

Here is some information about the __Company__ Schneider that produces the __Product__:

- A pen manufacturer.
- The __Company__ has these __NACE__ codes: A1, B2.

### Locations

The __Product__ is produced in these __Locations__: 

1. Tennenbronn  ([])

### Emissions

The CO2e __Emissions__ of the __Product__ are:

- Emissions in Tennenbronn (by Stage): 
- Rohstofferwerb: 67.728 kg
- Produktion: `None`
- Verteilung: `None`

## Activities

The __Activities__ are organized in __Sub-Stages__ of __Stages__ that are __Location__-based as well as in __Stages__ that are __Location__-independent.

### Tennenbronn
#### Rohstofferwerb

This __Stage__ has no description.

The __Stage__ "Rohstofferwerb" emits a total of 67.728 kg CO2e __Emissions__.
##### Rohstoffe und Vorprodukte

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Rohstoffe und Vorprodukte" emits a total of 65.045 kg CO2e __Emissions__.

- **Activity "Farbstoff - Batch"**: __Total Emissions__ amount to 0.56 kg CO2e emissions, derived from 173.197 g of __Input__ and an __Emission Factor__ of 3.232 kg CO2e/kg.
- **Activity "PES (Polyester)"**: __Total Emissions__ amount to 0.424 kg CO2e emissions, derived from 86.560305 g of __Input__ and an __Emission Factor__ of 4.898 kg CO2e/kg.
- **Activity "POM"**: __Total Emissions__ amount to 2.329 kg CO2e emissions, derived from 720.974 g of __Input__ and an __Emission Factor__ of 3.231 kg CO2e/kg.
- **Activity "TPE"**: __Total Emissions__ amount to 12.027 kg CO2e emissions, derived from 1563.2 g of __Input__ and an __Emission Factor__ of 7.694 kg CO2e/kg.
- **Activity "Edelstahl"**: __Total Emissions__ amount to 1.388 kg CO2e emissions, derived from 405 g of __Input__ and an __Emission Factor__ of 3.427 kg CO2e/kg.
- **Activity "Stahl"**: __Total Emissions__ amount to 12.985 kg CO2e emissions, derived from 5992 g of __Input__ and an __Emission Factor__ of 2.167 kg CO2e/kg.
- **Activity "ABS - Recycling"**: __Total Emissions__ amount to 20.037 kg CO2e emissions, derived from 4448.7 g of __Input__ and an __Emission Factor__ of 4.504 kg CO2e/kg.
- **Activity "EPS (Schaumstoff)"**: __Total Emissions__ amount to 0.014 kg CO2e emissions, derived from 4 g of __Input__ and an __Emission Factor__ of 3.48 kg CO2e/kg.
- **Activity "Hartmetall"**: __Total Emissions__ amount to 0.415 kg CO2e emissions, derived from 22.1 g of __Input__ and an __Emission Factor__ of 18.776 kg CO2e/kg.
- **Activity "Messing"**: __Total Emissions__ amount to 10.172 kg CO2e emissions, derived from 1800 g of __Input__ and an __Emission Factor__ of 5.651 kg CO2e/kg.
- **Activity "ABS"**: __Total Emissions__ amount to 2.471 kg CO2e emissions, derived from 548.529 g of __Input__ and an __Emission Factor__ of 4.504 kg CO2e/kg.
- **Activity "Paste"**: __Total Emissions__ amount to 0.769 kg CO2e emissions, derived from 1050 g of __Input__ and an __Emission Factor__ of 0.732 kg CO2e/kg.
- **Activity "Abschlussmasse"**: __Total Emissions__ amount to 1.454 kg CO2e emissions, derived from 200 g of __Input__ and an __Emission Factor__ of 7.269 kg CO2e/kg.

##### Verpackungsmaterial

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Verpackungsmaterial" emits a total of 2.683 kg CO2e __Emissions__.

- **Activity "Wellpappe"**: __Total Emissions__ amount to 0.647 kg CO2e emissions, derived from 806.35 g of __Input__ and an __Emission Factor__ of 0.802 kg CO2e/kg.
- **Activity "PE (außer Folie)"**: __Total Emissions__ amount to 0.041 kg CO2e emissions, derived from 16.7 g of __Input__ and an __Emission Factor__ of 2.481 kg CO2e/kg.
- **Activity "Papier (bis 250 g/m2)"**: There are no total CO2e emissions, derived from 6.9 g of __Input__ and an __Emission Factor__ of 0.048 kg CO2e/kg.
- **Activity "Pappe / Karton (ab 251 g/m^2)"**: __Total Emissions__ amount to 1.995 kg CO2e emissions, derived from 2487.4 g of __Input__ and an __Emission Factor__ of 0.802 kg CO2e/kg.

##### Eingangslogistik

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Eingangslogistik" emits no CO2e __Emissions__.

- **Activity "lorry1632"**: There are no total CO2e emissions.
- **Activity "aircargo"**: There are no total CO2e emissions.
- **Activity "containership"**: There are no total CO2e emissions.

##### Lagerung

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Lagerung" emits no CO2e __Emissions__.

#### Produktion

This __Stage__ has no description.

The __Stage__ "Produktion" emits no CO2e __Emissions__.
##### Brennstoffverbrauch

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Brennstoffverbrauch" emits no CO2e __Emissions__.

##### Kraftstoffverbrauch

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Kraftstoffverbrauch" emits no CO2e __Emissions__.

##### Stromverbrauch

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Stromverbrauch" emits no CO2e __Emissions__.

- **Activity "Stromverbrauch Kunststoff spritzen"**: There are no total CO2e emissions.
- **Activity "Stromverbrauch restliche Produktion"**: There are no total CO2e emissions.

##### Fernwärme

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Fernwärme" emits no CO2e __Emissions__.

##### Wasserverbrauch

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Wasserverbrauch" emits no CO2e __Emissions__.

##### Hilfs- und Verbrauchsstoffe

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Hilfs- und Verbrauchsstoffe" emits no CO2e __Emissions__.

##### Abfall und Abwasser

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Abfall und Abwasser" emits no CO2e __Emissions__.

##### Austauschlogistik

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Austauschlogistik" emits no CO2e __Emissions__.

##### Prozessemissionen

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Prozessemissionen" emits no CO2e __Emissions__.

##### Weitere

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Weitere" emits no CO2e __Emissions__.

#### Verteilung

This __Stage__ has no description.

The __Stage__ "Verteilung" emits no CO2e __Emissions__.
##### Ausgangslogistik

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Ausgangslogistik" emits no CO2e __Emissions__.

##### Lagerung

This __Sub-Stage__ has no description.

The __Sub-Stage__ "Lagerung" emits no CO2e __Emissions__.

### Location-independent

Location-independent Activities are not grouped in Sub-Stages.
#### Nutzung

This __Stage__ has no description.

The Stage "Nutzung" emits no CO2e emissions.

#### End-of-life

This __Stage__ has no description.

The Stage "End-of-life" emits a total of 11.63 kg CO2e emissions.

- **Activity "Restmüll"**: There are no total CO2e emissions. __Comment__: "Wieso ist dieser Faktor halb so hoch?".
- **Activity "residualWaste"**: __Total Emissions__ amount to 11.63 kg CO2e emissions, derived from 17515 g of __Input__.

### Commented

Users can add a __Comment__ to any __Activity__. 
It is likely that a comment indicates open tasks or questions, so take them into account.
This is a list of all __Activities__ that are commented:

- End-of-life > Restmüll: Wieso ist dieser Faktor halb so hoch?
## Missing Fields

Location-based measures with missing emissions:

- Papier (bis 250 g/m2) (in Location Tennenbronn, Stage Rohstofferwerb, Sub-Stage Verpackungsmaterial) is missing a consumption value.
- lorry1632 (in Location Tennenbronn, Stage Rohstofferwerb, Sub-Stage Eingangslogistik) is missing a consumption value.
- aircargo (in Location Tennenbronn, Stage Rohstofferwerb, Sub-Stage Eingangslogistik) is missing a consumption value.
- containership (in Location Tennenbronn, Stage Rohstofferwerb, Sub-Stage Eingangslogistik) is missing a consumption value.
- Stromverbrauch Kunststoff spritzen (in Location Tennenbronn, Stage Produktion, Sub-Stage Stromverbrauch) is missing a consumption value.
- Stromverbrauch restliche Produktion (in Location Tennenbronn, Stage Produktion, Sub-Stage Stromverbrauch) is missing a consumption value.

Location-independent measures with missing emissions:

- Restmüll (in Stage End-of-life) a consumption value is missing.
